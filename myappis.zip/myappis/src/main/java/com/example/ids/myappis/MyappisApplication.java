package com.example.ids.myappis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//clase principal
@SpringBootApplication
public class MyappisApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyappisApplication.class, args);
	}

}
